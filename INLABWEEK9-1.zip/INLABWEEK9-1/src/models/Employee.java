package models;

public class Employee implements Comparable<Employee> {
    private String name;
    private int age;
    private int experience;
    private double salary;

    public Employee(String name, int age, int experience, double salary) {
        this.name = name;
        this.age = age;
        this.experience = experience;
        this.salary = salary;
    }

    public int getExperience() {
        return experience;
    }

    public double getSalary() {
        return salary;
    }

    public void addBonus(double bonus) {
        this.salary += bonus;
    }

    @Override
    public int compareTo(Employee other) {
        return Integer.compare(other.experience, this.experience);  // Sort by experience (Descending)
    }

    @Override
    public String toString() {
        return name + " (Age: " + age + ", Experience: " + experience + " years, Salary: $" + salary + ")";
    }
}
