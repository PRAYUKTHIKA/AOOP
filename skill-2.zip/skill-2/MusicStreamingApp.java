import java.util.*;
// Interface for Music Source
interface MusicSource {
    void play();
}

// Local File Music Player
class LocalFilePlayer implements MusicSource {
    private String fileName;
    
    public LocalFilePlayer(String fileName) {
        this.fileName = fileName;
    }
    
    @Override
    public void play() {
        System.out.println("Playing local file: " + fileName);
    }
}

// Online Streaming Service Player (Adapter)
class OnlineStreamingService {
    public void stream(String songName) {
        System.out.println("Streaming song from online service: " + songName);
    }
}

class OnlineStreamingAdapter implements MusicSource {
    private OnlineStreamingService service;
    private String songName;
    
    public OnlineStreamingAdapter(OnlineStreamingService service, String songName) {
        this.service = service;
        this.songName = songName;
    }
    
    @Override
    public void play() {
        service.stream(songName);
    }
}

// Radio Station Player
class RadioStationPlayer implements MusicSource {
    private String stationName;
    
    public RadioStationPlayer(String stationName) {
        this.stationName = stationName;
    }
    
    @Override
    public void play() {
        System.out.println("Playing radio station: " + stationName);
    }
}

// Facade for Music Player
class MusicPlayerFacade {
    public void playLocal(String fileName) {
        new LocalFilePlayer(fileName).play();
    }
    
    public void playOnline(String songName) {
        new OnlineStreamingAdapter(new OnlineStreamingService(), songName).play();
    }
    
    public void playRadio(String stationName) {
        new RadioStationPlayer(stationName).play();
    }
}

// Composite Pattern for Playlist


class Playlist implements MusicSource {
    private List<MusicSource> songs = new ArrayList<>();
    
    public void addSong(MusicSource song) {
        songs.add(song);
    }
    
    @Override
    public void play() {
        System.out.println("Playing playlist:");
        for (MusicSource song : songs) {
            song.play();
        }
    }
}

// Main Class
public class MusicStreamingApp {
    public static void main(String[] args) {
        MusicPlayerFacade player = new MusicPlayerFacade();
        
        // Playing different types of music
        player.playLocal("song1.mp3");
        player.playOnline("Despacito");
        player.playRadio("Classic FM");
        
        // Creating a playlist
        Playlist playlist = new Playlist();
        playlist.addSong(new LocalFilePlayer("song2.mp3"));
        playlist.addSong(new OnlineStreamingAdapter(new OnlineStreamingService(), "Shape of You"));
        playlist.addSong(new RadioStationPlayer("Jazz FM"));
        
        playlist.play();
    }
}
