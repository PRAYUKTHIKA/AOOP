package mypackage;

public interface Weapon {
	void use();

}
