package mypackage;

public class Vampire extends Enemy {
	public void attack() {
        System.out.println("Vampire attacks by biting!");
    }

}
