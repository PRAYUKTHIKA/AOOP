package mypackage;

public interface Powerup {
	void activate();

}
