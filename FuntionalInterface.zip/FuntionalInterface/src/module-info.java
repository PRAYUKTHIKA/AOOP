/**
 * 
 */
/**
 * 
 */
module FuntionalInterface {
}