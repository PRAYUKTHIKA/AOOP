package main;

import models.Employee;
import services.EmployeeService;
import java.util.List;
import java.util.Optional;

public class EmployeeOperationsMain {
    public static void main(String[] args) {
        List<Employee> employees = List.of(
                new Employee("Alice", 30, "IT", 5000),
                new Employee("Bob", 28, "HR", 4000),
                new Employee("Charlie", 35, "Finance", 6000),
                new Employee("David", 32, "IT", 5500),
                new Employee("Eve", 29, "HR", 4200)
        );

        EmployeeService service = new EmployeeService(employees);

        
        System.out.println("Employees in IT Department:");
        service.filterByDepartment("IT").forEach(System.out::println);

        
        System.out.println("\nEmployees sorted by name:");
        service.sortByName().forEach(System.out::println);

        
        Optional<Employee> highestPaid = service.findHighestSalary();
        highestPaid.ifPresent(emp -> System.out.println("\nEmployee with highest salary: " + emp));

       
        System.out.println("\nAverage Salary: $" + service.calculateAverageSalary());
    }
}
