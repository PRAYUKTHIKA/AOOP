package StreamAPI;

import java.util.*;
import java.util.stream.*;

public class StreamExample {
    public static void main(String[] args) {
      List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);
        
// Using Stream to process the list
        numbers.stream().forEach(System.out::println);
//Filtering Even Numbers
        List<Integer> numbers1 = Arrays.asList(1, 2, 3, 4, 5, 6);
    	List<Integer> evenNumbers = numbers1.stream().filter(n -> n % 2 == 0).collect(Collectors.toList());
    	System.out.println(evenNumbers); // Output: [2, 4, 6]
//Transforming Data (map)
    	List<String> names = Arrays.asList("john", "mike", "sara");
    	List<String> uppercaseNames = names.stream().map(String::toUpperCase).collect(Collectors.toList());
    	System.out.println(uppercaseNames); // Output: [JOHN, MIKE, SARA]
//Sorting a List
    	List<Integer> numbers2 = Arrays.asList(5, 2, 8, 1, 4);
    	List<Integer> sortedNumbers = numbers2.stream().sorted().collect(Collectors.toList());
    	System.out.println(sortedNumbers); // Output: [1, 2, 4, 5, 8]
 //Finding Sum using Reduce
    	int sum = Arrays.asList(1, 2, 3, 4, 5).stream().reduce(0, (a, b) -> a + b);
    	System.out.println("Sum: " + sum); // Output: 15
//
    }
}
