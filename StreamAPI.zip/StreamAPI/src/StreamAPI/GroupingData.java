package StreamAPI;

import java.util.*;
import java.util.stream.*;

class Employee {
    String department;
    String name;

    Employee(String department, String name) {
        this.department = department;
        this.name = name;
    }
}

public class GroupingData {
    public static void main(String[] args) {
        List<Employee> employees = Arrays.asList(
            new Employee("HR", "John"),
            new Employee("IT", "Alice"),
            new Employee("HR", "Mike"),
            new Employee("IT", "Bob")
        );

        Map<String, List<Employee>> grouped = employees.stream().collect(Collectors.groupingBy(e -> e.department));
        System.out.println(grouped);
    }
}
