// Singleton: GameManager (Manages game levels)
class GameManager {
    private static GameManager instance;

    private GameManager() {}

    public static GameManager getInstance() {
        if (instance == null) {
            instance = new GameManager();
        }
        return instance;
    }

    public void startGame(LevelFactory factory) {
        Level level = factory.createLevel();
        System.out.println("Starting game at difficulty: " + level.getDifficulty());
        level.start();
    }
}

// Factory Method: Level interface and concrete implementations
interface Level {
    String getDifficulty();
    void start();
}

class EasyLevel implements Level {
    public String getDifficulty() { return "Easy"; }
    public void start() { System.out.println("Easy Level Started!"); }
}

class HardLevel implements Level {
    public String getDifficulty() { return "Hard"; }
    public void start() { System.out.println("Hard Level Started!"); }
}

// Abstract Factory: LevelFactory and concrete factories
interface LevelFactory {
    Level createLevel();
}

class EasyLevelFactory implements LevelFactory {
    public Level createLevel() { return new EasyLevel(); }
}

class HardLevelFactory implements LevelFactory {
    public Level createLevel() { return new HardLevel(); }
}

// Singleton: RideManager (Manages ride requests)
class RideManager {
    private static RideManager instance;

    private RideManager() {}

    public static RideManager getInstance() {
        if (instance == null) {
            instance = new RideManager();
        }
        return instance;
    }

    public void requestRide(RideFactory factory, String location) {
        Vehicle vehicle = factory.createVehicle();
        System.out.println("Ride requested at " + location + " with a " + vehicle.getType());
        vehicle.startRide();
    }
}

// Factory Method: Vehicle interface and concrete implementations
interface Vehicle {
    String getType();
    void startRide();
}

class Car implements Vehicle {
    public String getType() { return "Car"; }
    public void startRide() { System.out.println("Car ride started!"); }
}

class Bike implements Vehicle {
    public String getType() { return "Bike"; }
    public void startRide() { System.out.println("Bike ride started!"); }
}

class Scooter implements Vehicle {
    public String getType() { return "Scooter"; }
    public void startRide() { System.out.println("Scooter ride started!"); }
}

// Abstract Factory: RideFactory and concrete factories
interface RideFactory {
    Vehicle createVehicle();
}

class EconomyRideFactory implements RideFactory {
    public Vehicle createVehicle() { return new Bike(); }
}

class LuxuryRideFactory implements RideFactory {
    public Vehicle createVehicle() { return new Car(); }
}

// Main Application
public class Main {
    public static void main(String[] args) {
        // Game Application
        GameManager gameManager = GameManager.getInstance();
        gameManager.startGame(new EasyLevelFactory());
        gameManager.startGame(new HardLevelFactory());

        System.out.println("-------------------------------");

        // Ride-Sharing Application
        RideManager rideManager = RideManager.getInstance();
        rideManager.requestRide(new EconomyRideFactory(), "Downtown");
        rideManager.requestRide(new LuxuryRideFactory(), "Airport");
    }
}
