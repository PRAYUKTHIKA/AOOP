package CC;
import java.util.*;
public class ComparatorExampla {
 public static void main(String[] args) {
     List<Student1> list = new ArrayList<>();
     list.add(new Student1(3, "Alice"));
     list.add(new Student1(1, "Bob"));
     list.add(new Student1(2, "Charlie"));

     // Sort by Name
     Collections.sort(list, new SortByName());
     System.out.println("Sorted by Name: " + list);

     // Sort by Roll Number
     Collections.sort(list, new SortByRollNo());
     System.out.println("Sorted by Roll No: " + list);
 }
}
