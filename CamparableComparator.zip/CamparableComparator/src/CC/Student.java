package CC;

class Student implements Comparable<Student> {
    int rollNo;
    String name;

    public Student(int rollNo, String name) {
        this.rollNo = rollNo;
        this.name = name;
    }

    // Implement compareTo() method for natural ordering by roll number
    public int compareTo(Student s) {
        return this.rollNo - s.rollNo;  // Ascending order
    }

    public String toString() {
        return rollNo + " - " + name;
    }
}