package CC;

import java.util.Comparator;

//Student class
class Student1 {
int rollNo;
String name;

public Student1(int rollNo, String name) {
   this.rollNo = rollNo;
   this.name = name;
}

public String toString() {
   return rollNo + " - " + name;
}
}

//Comparator to sort by Name
class SortByName implements Comparator<Student> {
public int compare(Student s1, Student s2) {
   return s1.name.compareTo(s2.name);
}
}

//Comparator to sort by Roll Number
class SortByRollNo implements Comparator<Student> {
public int compare(Student s1, Student s2) {
   return s1.rollNo - s2.rollNo;
}
}
