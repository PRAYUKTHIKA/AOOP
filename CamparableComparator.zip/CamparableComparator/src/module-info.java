/**
 * 
 */
/**
 * 
 */
module CamparableComparator {
}