package models;

import java.util.*;

public class ContactManager {
    private Map<String, String> contacts;

    public ContactManager() {
        this.contacts = new HashMap<>();
    }

    // Add a contact
    public void addContact(String name, String phoneNumber) {
        contacts.put(name, phoneNumber);
        System.out.println("Contact added: " + name + " -> " + phoneNumber);
    }

    // Retrieve a contact by name
    public String getContact(String name) {
        return contacts.getOrDefault(name, "Contact not found");
    }

    // Remove a contact by name
    public void removeContact(String name) {
        if (contacts.remove(name) != null) {
            System.out.println("Contact removed: " + name);
        } else {
            System.out.println("Contact not found: " + name);
        }
    }

    // Display all contacts
    public void displayContacts() {
        if (contacts.isEmpty()) {
            System.out.println("No contacts available.");
            return;
        }
        System.out.println("\n--- Contact List ---");
        contacts.forEach((name, phone) -> System.out.println(name + " -> " + phone));
    }
}
