import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

interface Enrollable {
    void enroll(Student student);
    void unenroll(Student student);
}

class Student {
    private String name;
    private String studentId;
    private List<Course> courses;

    public Student(String name, String studentId) {
        this.name = name;
        this.studentId = studentId;
        this.courses = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public String getStudentId() {
        return studentId;
    }

    public List<Course> getCourses() {
        return courses;
    }

    public void enroll(Course course) {
        if (!courses.contains(course)) {
            courses.add(course);
            course.enroll(this);
        }
    }

    public void unenroll(Course course) {
        if (courses.contains(course)) {
            courses.remove(course);
            course.unenroll(this);
        }
    }
}

class Course implements Enrollable {
    private String courseId;
    private String courseName;
    private List<Student> students;

    public Course(String courseId, String courseName) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.students = new ArrayList<>();
    }

    public String getCourseId() {
        return courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public List<Student> getStudents() {
        return students;
    }

    @Override
    public void enroll(Student student) {
        if (!students.contains(student)) {
            students.add(student);
        }
    }

    @Override
    public void unenroll(Student student) {
        students.remove(student);
    }
}

abstract class StudentType {
    protected String type;
    protected Student student;

    public StudentType(Student student) {
        this.student = student;
    }

    public String getType() {
        return type;
    }

    public abstract void displayInfo();
}

class FullTimeStudent extends StudentType {
    public FullTimeStudent(Student student) {
        super(student);
        this.type = "Full-Time";
    }

    @Override
    public void displayInfo() {
        System.out.println("Full-Time Student: " + student.getName() + " (ID: " + student.getStudentId() + ")");
    }
}

class PartTimeStudent extends StudentType {
    public PartTimeStudent(Student student) {
        super(student);
        this.type = "Part-Time";
    }

    @Override
    public void displayInfo() {
        System.out.println("Part-Time Student: " + student.getName() + " (ID: " + student.getStudentId() + ")");
    }
}

interface EnrollmentService {
    void enrollStudent(Student student, Course course);
    void unenrollStudent(Student student, Course course);
}

interface StudentInfoService {
    void displayStudentInfo(Student student);
}

class EnrollmentServiceImpl implements EnrollmentService {
    @Override
    public void enrollStudent(Student student, Course course) {
        student.enroll(course);
    }

    @Override
    public void unenrollStudent(Student student, Course course) {
        student.unenroll(course);
    }
}

class StudentInfoServiceImpl implements StudentInfoService {
    @Override
    public void displayStudentInfo(Student student) {
        System.out.println("Student Name: " + student.getName() + " (ID: " + student.getStudentId() + ")");
        System.out.println("Courses Enrolled: ");
        for (Course course : student.getCourses()) {
            System.out.println("- " + course.getCourseName());
        }
    }
}

public class TaskFive {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter student name: ");
        String studentName = scanner.nextLine();

        System.out.print("Enter student ID: ");
        String studentId = scanner.nextLine();

        Student student = new Student(studentName, studentId);

        Course course1 = new Course("C001", "Mathematics");
        Course course2 = new Course("C002", "Computer Science");
        Course course3 = new Course("C003", "Physics");
        Course course4 = new Course("C004", "Chemistry");
        Course course5 = new Course("C005", "Biology");
        Course course6 = new Course("C006", "History");
        Course course7 = new Course("C007", "Literature");
        Course course8 = new Course("C008", "Philosophy");

        System.out.println("\nChoose courses to enroll:");
        System.out.println("1. Mathematics (C001)");
        System.out.println("2. Computer Science (C002)");
        System.out.println("3. Physics (C003)");
        System.out.println("4. Chemistry (C004)");
        System.out.println("5. Biology (C005)");
        System.out.println("6. History (C006)");
        System.out.println("7. Literature (C007)");
        System.out.println("8. Philosophy (C008)");
        System.out.print("\nEnter course numbers to enroll (e.g., 1,3,5): ");
        String courseNumbers = scanner.nextLine();

        String[] selectedCourses = courseNumbers.split(",");
        EnrollmentService enrollmentService = new EnrollmentServiceImpl();

        for (String courseNum : selectedCourses) {
            switch (courseNum.trim()) {
                case "1":
                    enrollmentService.enrollStudent(student, course1);
                    break;
                case "2":
                    enrollmentService.enrollStudent(student, course2);
                    break;
                case "3":
                    enrollmentService.enrollStudent(student, course3);
                    break;
                case "4":
                    enrollmentService.enrollStudent(student, course4);
                    break;
                case "5":
                    enrollmentService.enrollStudent(student, course5);
                    break;
                case "6":
                    enrollmentService.enrollStudent(student, course6);
                    break;
                case "7":
                    enrollmentService.enrollStudent(student, course7);
                    break;
                case "8":
                    enrollmentService.enrollStudent(student, course8);
                    break;
                default:
                    System.out.println("Invalid course number: " + courseNum);
            }
        }

        StudentInfoService studentInfoService = new StudentInfoServiceImpl();
        studentInfoService.displayStudentInfo(student);

        System.out.print("\nWould you like to unenroll from a course? (yes/no): ");
        scanner.nextLine(); 
        String unenrollChoice = scanner.nextLine();

        if (unenrollChoice.equalsIgnoreCase("yes")) {
            System.out.println("Choose course to unenroll from:");
            System.out.println("1. Mathematics (C001)");
            System.out.println("2. Computer Science (C002)");
            System.out.println("3. Physics (C003)");
            System.out.println("4. Chemistry (C004)");
            System.out.println("5. Biology (C005)");
            System.out.println("6. History (C006)");
            System.out.println("7. Literature (C007)");
            System.out.println("8. Philosophy (C008)");
            System.out.print("Enter course number to unenroll: ");
            int unenrollChoiceNum = scanner.nextInt();

            switch (unenrollChoiceNum) {
                case 1:
                    enrollmentService.unenrollStudent(student, course1);
                    break;
                case 2:
                    enrollmentService.unenrollStudent(student, course2);
                    break;
                case 3:
                    enrollmentService.unenrollStudent(student, course3);
                    break;
                case 4:
                    enrollmentService.unenrollStudent(student, course4);
                    break;
                case 5:
                    enrollmentService.unenrollStudent(student, course5);
                    break;
                case 6:
                    enrollmentService.unenrollStudent(student, course6);
                    break;
                case 7:
                    enrollmentService.unenrollStudent(student, course7);
                    break;
                case 8:
                    enrollmentService.unenrollStudent(student, course8);
                    break;
                default:
                    System.out.println("Invalid course number: " + unenrollChoiceNum);
            }
        }

        studentInfoService.displayStudentInfo(student);

        scanner.close(); 
    }
}
