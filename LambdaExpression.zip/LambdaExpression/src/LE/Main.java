package LE;

public class Main {
	 public static void main(String[] args) {
		  MyInterface obj = () -> System.out.println("Hello from Lambda!");
	       
		// MyInterface obj = new Demo();
	     obj.show();
	 }
	}
