package LE;

class Demo implements MyInterface {
	 public void show() {
	     System.out.println("Hello from show method");
	 }
	}
