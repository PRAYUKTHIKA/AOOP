package LE;

public interface MyInterface {
	 void show();
}
